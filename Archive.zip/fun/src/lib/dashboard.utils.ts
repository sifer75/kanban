export const recent = [
  "Calendrier",
  "Presentation",
  "Document",
  "Tableau",
  "Liste de tâches",
  "excalidraw",
] as const;

export const colors = [
  "bg-[#C0A7D9]",
  "bg-[#F67B7B]",
  "bg-[#F5C144]",
  "bg-[#486046]",
  "bg-[#5D71DE]",
];
